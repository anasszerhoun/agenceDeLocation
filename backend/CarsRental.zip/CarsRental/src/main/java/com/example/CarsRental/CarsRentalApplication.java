package com.example.CarsRental;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarsRentalApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarsRentalApplication.class, args);
	}

}
